import numpy as np
import math
from scipy.sparse import lil_matrix, diags


# --------------------------
# 1. 工具函数适配：优化子空间梯度修正
# --------------------------
def projected_gradient_subspace(x, g, R):
    """
    优化子空间投影：精确处理稀疏矩阵的非零列
    """
    gP = g.copy()

    # 1. 非负约束修正
    mask_nonneg = (x <= 1e-12) & (g > 0)
    gP[mask_nonneg] = 0.0

    # 2. 子空间约束：精确获取非零列索引
    # 使用getnnz(axis=0)获取每列非零元素计数
    nnz_per_col = R.getnnz(axis=0)
    mask_zero_cols = (nnz_per_col == 0)
    gP[mask_zero_cols] = 0.0

    return gP


# --------------------------
# 2. 内层SBB算法：支持正则化项
# --------------------------
class SBBOptions:
    def __init__(self):
        self.max_iters = 5000
        self.tol_pg_inf = 1e-6
        self.gamma = 0.9
        self.alpha_min = 1e-16
        self.alpha_max = 1e+16
        self.alternate_BB = True
        self.verbose = False


class SBBResult:
    def __init__(self):
        self.x = None
        self.iters = 0
        self.pg_inf = np.inf


def sbb_nonneg_paper_reg(R, e, beta, x0, opt):
    """
    支持正则化的SBB算法：避免显式计算R^T R
    梯度计算：g = R^T(Rx - e) + beta * x
    """
    n = R.shape[1]
    x = np.maximum(x0.copy(), 0.0)
    use_bb1 = True
    grad_prev = np.zeros(n)

    for k in range(opt.max_iters):
        # 计算残差和梯度
        Rx = R @ x
        residual = Rx - e
        g = R.T @ residual + beta * x

        # 投影梯度修正
        gP = projected_gradient_subspace(x, g, R)

        # 收敛判断
        pg_inf = np.max(np.abs(gP))
        if pg_inf <= opt.tol_pg_inf:
            res = SBBResult()
            res.x = x
            res.iters = k
            res.pg_inf = pg_inf
            return res

        # 计算BB步长（避免显式计算R^T R）
        # 计算R @ gP 和 R.T @ (R @ gP)
        R_gP = R @ gP
        RtR_gP = R.T @ R_gP

        # 添加正则化项：H = R^T R + beta I
        H_gP = RtR_gP + beta * gP

        # 第一种BB步长
        numerator1 = np.dot(gP, gP)
        denominator1 = np.dot(gP, H_gP)
        alpha1 = numerator1 / denominator1 if denominator1 > 1e-12 else opt.alpha_max

        # 第二种BB步长
        numerator2 = denominator1
        denominator2 = np.dot(H_gP, H_gP)
        alpha2 = numerator2 / denominator2 if denominator2 > 1e-12 else opt.alpha_max

        # 选择步长
        alpha = alpha1 if use_bb1 else alpha2
        if opt.alternate_BB:
            use_bb1 = not use_bb1
        alpha = max(opt.alpha_min, min(opt.alpha_max, opt.gamma * alpha))

        # 非负更新
        x_new = np.maximum(x - alpha * gP, 0.0)

        # 步长回溯（防止无效更新）
        if np.linalg.norm(x_new - x) < 1e-16:
            alpha *= 0.5
            x_new = np.maximum(x - alpha * gP, 0.0)

        x = x_new
        grad_prev = gP

    # 最大迭代后返回结果
    Rx_final = R @ x
    residual_final = Rx_final - e
    g_final = R.T @ residual_final + beta * x
    gP_final = projected_gradient_subspace(x, g_final, R)
    res = SBBResult()
    res.x = x
    res.iters = opt.max_iters
    res.pg_inf = np.max(np.abs(gP_final))
    return res


# --------------------------
# 3. 外层自适应正则化：优化实现
# --------------------------
def solve_adaptive_tikhonov_SBB_paper(R, e, beta0, t0, sbb_opt, out_opt):
    n = R.shape[1]
    t = np.maximum(t0.copy(), 0.0) if t0.size == n else np.zeros(n)
    beta = max(0.0, beta0)
    inner_sum = 0

    for k in range(out_opt.max_outer):
        # 直接调用支持正则化的SBB求解器
        inner = sbb_nonneg_paper_reg(R, e, beta, t, sbb_opt)
        inner_sum += inner.iters
        t_next = inner.x

        # 计算相对变化平方
        t_sq_norm = np.dot(t, t)
        denom = max(out_opt.eps_guard, t_sq_norm)
        rel_change_sq = np.dot(t_next - t, t_next - t) / denom

        # 更新正则化参数
        r = R @ t_next - e
        t_next_sq_norm = max(out_opt.eps_guard, np.dot(t_next, t_next))
        beta_new = math.log(1.0 + np.dot(r, r) / t_next_sq_norm)

        if out_opt.verbose:
            print(f"[Outer] k={k} beta={beta:.6f} beta_new={beta_new:.6f} "
                  f"rel_change_sq={rel_change_sq:.6e} ||pg||_inf={inner.pg_inf:.6e}")

        # 更新变量
        t = t_next
        beta = beta_new

        # 收敛判断
        if rel_change_sq <= out_opt.delta_sq:
            return {"t": t, "beta": beta, "outer_iters": k + 1, "inner_iters_total": inner_sum}

    return {"t": t, "beta": beta, "outer_iters": out_opt.max_outer, "inner_iters_total": inner_sum}


# --------------------------
# 4. 演示：保持不变
# --------------------------
def main():
    import scipy.sparse as sp
    m, n = 40000, 10000
    np.random.seed(42)

    # 生成稀疏非负R矩阵
    R = sp.lil_matrix((m, n), dtype=np.float64)
    non_zero_ratio = 0.01
    non_zero_count = int(m * n * non_zero_ratio)
    row_idx = np.random.randint(0, m, non_zero_count)
    col_idx = np.random.randint(0, n, non_zero_count)
    R[row_idx, col_idx] = np.random.rand(non_zero_count)

    # 生成真实驻留时间
    t_true = np.random.rand(n) * 0.5

    # 生成观测值
    e = R @ t_true+ 0.001 * np.random.randn(m)
    e = np.maximum(e, 0.0)

    # 算法参数
    sbb_opt = SBBOptions()
    sbb_opt.tol_pg_inf = 1e-6
    sbb_opt.max_iters = 5000
    out_opt = type('OuterOptions', (), {
        "max_outer": 50, "delta_sq": 1e-4, "eps_guard": 1e-12, "verbose": True
    })()
    beta0 = 1.0
    t0 = np.zeros(n)

    # 求解
    res = solve_adaptive_tikhonov_SBB_paper(R, e, beta0, t0, sbb_opt, out_opt)
    print(f"\nFinal: beta={res['beta']:.6f}, outer_iters={res['outer_iters']}, inner_iters={res['inner_iters_total']}")
    print(f"t_true前10个元素: {t_true[:10].round(4)}")
    print(f"求解t前10个元素: {res['t'][:10].round(4)}")


if __name__ == "__main__":
    main()