import sys
from PySide2.QtWidgets import QApplication, QMainWindow, QFileDialog, QPushButton, QLineEdit, QTextEdit, QGraphicsView, QGraphicsScene, QVBoxLayout, QWidget
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import QFile
import torch
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from mpl_toolkits.mplot3d import Axes3D

class MainApp(QMainWindow):
    def __init__(self):
        super(MainApp, self).__init__()
        self.initUI()

    def initUI(self):
        # Load the UI file
        ui_file = QFile("test.ui")
        if not ui_file.exists():
            print("UI file not found")
            sys.exit(-1)
        ui_file.open(QFile.ReadOnly)
        loader = QUiLoader()
        self.window = loader.load(ui_file)
        ui_file.close()

        if self.window is None:
            print("Failed to load the UI file.")
            sys.exit(-1)

        # Connect buttons to their functions
        import_data_btn = self.window.findChild(QPushButton, "pushButton")
        import_weights_btn = self.window.findChild(QPushButton, "pushButton_2")
        compute_distribution_btn = self.window.findChild(QPushButton, "pushButton_3")
        export_distribution_btn = self.window.findChild(QPushButton, "pushButton_4")
        import_x_values_btn = self.window.findChild(QPushButton, "pushButton_5")

        if import_data_btn is None or import_weights_btn is None or compute_distribution_btn is None or export_distribution_btn is None or import_x_values_btn is None:
            print("One or more buttons not found in the UI file.")
            sys.exit(-1)

        import_data_btn.clicked.connect(self.import_data)
        import_weights_btn.clicked.connect(self.import_weights)
        compute_distribution_btn.clicked.connect(self.compute_distribution)
        export_distribution_btn.clicked.connect(self.export_distribution)
        import_x_values_btn.clicked.connect(self.import_x_values)

        # Get QLineEdit widgets for pixel size and threshold
        self.pixel_size_input = self.window.findChild(QLineEdit, "lineEdit_2")
        self.threshold_input = self.window.findChild(QLineEdit, "lineEdit")

        # Get QTextEdit for logging
        self.text_edit = self.window.findChild(QTextEdit, "textEdit")

        # Get QGraphicsView for plotting
        self.graphics_view = self.window.findChild(QGraphicsView, "graphicsView")
        self.graphics_view_2 = self.window.findChild(QGraphicsView, "graphicsView_2")

        self.setCentralWidget(self.window)

    def log_message(self, message):
        self.text_edit.append(message)

    def import_data(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "导入缎带轮廓数据", "", "Text Files (*.txt);;All Files (*)", options=options)
        if file_name:
            self.data_path = file_name
            self.log_message(f"Data imported from: {file_name}")
            self.plot_data()

    def plot_data(self):
        data = np.loadtxt(self.data_path)
        data = np.where(data == -2147483648, np.nan, data)  # Replace invalid data with NaN
        x = np.arange(len(data)) * 0.02
        y = data

        fig, ax = plt.subplots()
        ax.plot(x, y, marker='o', linestyle='-', markersize=2)
        ax.set_xlabel('X (mm)')
        ax.set_ylabel('Y (mm)')
        ax.set_title('Magnetorheological fluid ribbon')
        ax.grid(True)

        canvas = FigureCanvas(fig)
        scene = QGraphicsScene()
        scene.addWidget(canvas)
        self.graphics_view.setScene(scene)
        canvas.draw()

    def import_weights(self):
        options = QFileDialog.Options()
        file_names, _ = QFileDialog.getOpenFileNames(self, "导入神经网络权重数据", "", "Model Files (*.pth);;All Files (*)", options=options)
        if file_names:
            self.weights_paths = file_names
            self.log_message(f"Weights imported from: {file_names}")

    def import_x_values(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "导入x_values数据", "", "Text Files (*.txt);;All Files (*)", options=options)
        if file_name:
            self.x_values_path = file_name
            self.x_values = np.loadtxt(self.x_values_path)[:, 0]
            self.log_message(f"x_values imported from: {file_name}")

    def compute_distribution(self):
        if not hasattr(self, 'data_path') or not hasattr(self, 'weights_paths') or not hasattr(self, 'x_values'):
            self.log_message("Please import data, weights files, and x_values first.")
            return

        # Get user input for pixel size and threshold
        try:
            pixel_size_given = float(self.pixel_size_input.text())
            threshold_value = float(self.threshold_input.text())
        except ValueError:
            self.log_message("Invalid pixel size or threshold value.")
            return

        input_data = np.loadtxt(self.data_path)  # Use imported data
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        input_tensor = torch.tensor(input_data, dtype=torch.float32).to(device)

        class MLP(torch.nn.Module):
            def __init__(self):
                super(MLP, self).__init__()
                self.fc1 = torch.nn.Linear(950, 1500)
                self.sigmoid = torch.nn.Sigmoid()
                self.fc2 = torch.nn.Linear(1500, 2000)
                self.fc3 = torch.nn.Linear(2000, 102 * 2)

            def forward(self, x):
                x = self.fc1(x)
                x = self.sigmoid(x)
                x = self.fc2(x)
                x = self.sigmoid(x)
                out = self.fc3(x)
                return out

        all_predictions = []

        for i, model_path in enumerate(self.weights_paths):
            model = MLP().to(device)
            model.load_state_dict(torch.load(model_path))
            model.eval()

            with torch.no_grad():
                outputs = model(input_tensor).cpu().numpy()
                yz_values = outputs.reshape(-1, 102, 2)
                for yz in yz_values:
                    yz[:, 1] = yz[:, 1]
                    slice_predictions = np.column_stack((np.full((102,), self.x_values[i]), yz))
                    all_predictions.append(slice_predictions)

        all_predictions_array = np.vstack(all_predictions)
        np.savetxt("predicted_3D_surface_full.txt", all_predictions_array, fmt='%.6f')

        self.log_message("The predicted 3D surface has been saved.")
        self.plot_predicted_surface("predicted_3D_surface_full.txt")

        metrics = self.compute_metrics("predicted_3D_surface_full.txt", pixel_size_given, threshold_value)
        self.log_message(str(metrics))

    def plot_predicted_surface(self, file_path):
        data_points = np.loadtxt(file_path)
        x, y, z = data_points[:, 0], data_points[:, 1], data_points[:, 2]

        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        sc = ax.scatter(x, y, z, c=z, cmap='jet')

        plt.colorbar(sc)
        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_zlabel('Z Axis')

        canvas = FigureCanvas(fig)
        scene = QGraphicsScene()
        scene.addWidget(canvas)
        self.graphics_view_2.setScene(scene)
        canvas.draw()

    def compute_metrics(self, file_path, pixel_size, threshold=0):
        data_points = np.loadtxt(file_path)
        x, y, z = data_points[:, 0], data_points[:, 1], data_points[:, 2]

        filtered_points = data_points[data_points[:, 2] > threshold]
        x_filtered, y_filtered, z_filtered = filtered_points[:, 0], filtered_points[:, 1], filtered_points[:, 2]

        dim1 = np.max(x_filtered) - np.min(x_filtered)
        dim2 = np.max(y_filtered) - np.min(y_filtered)
        length, width = max(dim1, dim2), min(dim1, dim2)

        aspect_ratio = length / width if width != 0 else 0
        peak_removal_rate = (np.max(z_filtered) * 1000) / 1000

        pixel_area = pixel_size ** 2
        volumes = z_filtered * pixel_area
        volume_removal_rate = np.sum(volumes) / 1000

        return {
            "Length (mm)": length,
            "Width (mm)": width,
            "Aspect Ratio": aspect_ratio,
            "Peak Removal Rate (um/min)": peak_removal_rate,
            "Volume Removal Rate (mm^3/min)": volume_removal_rate
        }

    def export_distribution(self):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getSaveFileName(self, "导出去除函数分布", "",
                                                       "Text Files (*.txt);;All Files (*)", options=options)
        if file_name:
            np.savetxt(file_name, np.loadtxt("predicted_3D_surface_full.txt"), fmt='%.6f')
            self.log_message(f"Distribution exported to: {file_name}")

def main():
    app = QApplication(sys.argv)
    main_app = MainApp()
    main_app.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()