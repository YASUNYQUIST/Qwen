import numpy as np
from scipy.optimize import fsolve

def equations(vars, a, b, theta):
    x, y = vars
    eq1 = (b - y) / (a - x) - (y - (0.18 - 0.18 * np.cos(theta))) / (x - 0.18 * np.sin(theta))
    eq2 = np.sqrt((a - x) ** 2 + (b - y) ** 2) - 0.108
    return [eq1, eq2]

# 示例参数值
a = 0.3891# 替换为实际的a值
b = 0.0981  # 替换为实际的b值
theta_degrees =15
theta = np.deg2rad(theta_degrees)

# 初始猜测值
initial_guess = [0.1, 0.1]

solution = fsolve(equations, initial_guess, args=(a, b, theta))
x, y = solution

print(f"求解得到的x = {x}, y = {y}")
# 求解线激光测量仪左右两端点坐标

#
# import numpy as np
#
#
# def solve_equation(x, R):
#     if x < 0:
#         raise ValueError("x must be non-negative")
#
#     # Calculate y
#     y = R - np.sqrt(R ** 2 - x ** 2)
#
#     # Check the constraint y <= 0.3
#     if y > 0.3:
#         raise ValueError(f"No solution: y = {y} exceeds 0.3")
#
#     return y
#
#
# # Example values
# x_value = 0.3891# Replace with actual x value
# r = 2
# R_value = (r*r+0.09)/0.6  # Replace with actual R value
#
# try:
#     y_value = solve_equation(x_value, R_value)
#     print(f"For x = {x_value} and R = {R_value}, the corresponding y = {0.0981-y_value}")
# except ValueError as e:
#     print(e)


