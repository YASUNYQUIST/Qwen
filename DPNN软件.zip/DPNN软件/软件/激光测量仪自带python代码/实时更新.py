import sys
import numpy as np
import pandas as pd
from PySide2.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox, QPushButton, QLineEdit, QWidget, QVBoxLayout, QSizePolicy
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import QFile, QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import LJXAwrap
import ctypes

# 全局变量
image_available = False
ysize_acquired = 0
z_val = []

#缎带轮廓显示窗口设置
class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.updateGeometry()

    def plot(self, x, y):
        self.axes.clear()
        self.axes.plot(x, y)
        self.draw()

#主窗口初始化
class MainApp(QMainWindow):
    def __init__(self):
        super(MainApp, self).__init__()
        self.initUI()

    def initUI(self):
        # 载入ui界面
        ui_file = QFile("untitled.ui")
        if not ui_file.exists():
            print("UI file not found")
            sys.exit(-1)
        ui_file.open(QFile.ReadOnly)
        loader = QUiLoader()
        self.window = loader.load(ui_file, self)
        ui_file.close()

        if self.window is None:
            print("Failed to load the UI file.")
            sys.exit(-1)


        #初始化通信按钮
        self.init_communication_btn = self.window.findChild(QPushButton, "pushButton")
        #开启实时缎带轮廓刷新按钮
        self.start_refresh_btn = self.window.findChild(QPushButton, "pushButton_2")
        #关闭实时缎带轮廓刷新按钮
        self.stop_refresh_btn = self.window.findChild(QPushButton, "pushButton_3")
        #开启记录缎带轮廓按钮
        self.start_record_btn = self.window.findChild(QPushButton, "pushButton_4")
        #关闭记录缎带轮廓按钮
        self.stop_record_btn = self.window.findChild(QPushButton, "pushButton_5")
        #选择轮廓数据保存地址按钮
        self.select_save_path_btn = self.window.findChild(QPushButton, "pushButton_18")

        if not all([self.init_communication_btn, self.start_refresh_btn, self.stop_refresh_btn, self.start_record_btn, self.stop_record_btn, self.select_save_path_btn]):
            print("One or more buttons not found in the UI file.")
            sys.exit(-1)

        #将函数与按钮关联
        self.init_communication_btn.clicked.connect(self.init_communication)
        self.start_refresh_btn.clicked.connect(self.start_refresh)
        self.stop_refresh_btn.clicked.connect(self.stop_refresh)
        self.start_record_btn.clicked.connect(self.start_record)
        self.stop_record_btn.clicked.connect(self.stop_record)
        self.select_save_path_btn.clicked.connect(self.select_save_path)

        # 输入框
        #ip地址
        self.ip_part_1 = self.window.findChild(QLineEdit, "lineEdit")
        self.ip_part_2 = self.window.findChild(QLineEdit, "lineEdit_2")
        self.ip_part_3 = self.window.findChild(QLineEdit, "lineEdit_3")
        self.ip_part_4 = self.window.findChild(QLineEdit, "lineEdit_4")
        #端口
        self.port_input = self.window.findChild(QLineEdit, "lineEdit_12")
        self.high_speed_port_input = self.window.findChild(QLineEdit, "lineEdit_13")
        #缎带轮廓保存地址
        self.save_path_display = self.window.findChild(QLineEdit, "lineEdit_10")

        # 创建两个 PlotCanvas 实例，用于显示缎带轮廓和傅里叶变换结果
        self.canvas = PlotCanvas(self.window.findChild(QWidget, "widget_1"), width=5, height=4)
        self.canvas_fft = PlotCanvas(self.window.findChild(QWidget, "widget_2"), width=5, height=4)

        #设置布局缎带显示窗口
        layout1 = QVBoxLayout(self.window.findChild(QWidget, "widget_1"))
        layout1.addWidget(self.canvas)
        layout1.setStretch(0, 1)
        #设置布局显示快速傅里叶变换后的缎带
        layout2 = QVBoxLayout(self.window.findChild(QWidget, "widget_2"))
        layout2.addWidget(self.canvas_fft)
        layout2.setStretch(0, 1)

        #中央显示窗口，选择按钮跳出
        self.setCentralWidget(self.window)
        #初始化定时器和其他成员变量
        #定时器，用于定期调用update_plot以刷新图像
        self.timer = QTimer()
        #用于保存缎带轮廓数据的缓冲区
        self.timer.timeout.connect(self.update_plot)
        #布尔变量，指示是否正在记录数据
        self.data_buffer = []
        #
        self.recording = False
        #
        self.save_path = ""
        #
        self.device_id = 0

        self.initialize_buffers()

    def initialize_buffers(self):
        global z_val
        z_val = [0] * 3200 * 1000


    def init_communication(self):
        ip_parts = [
            self.ip_part_1.text(),
            self.ip_part_2.text(),
            self.ip_part_3.text(),
            self.ip_part_4.text()
        ]
        port = int(self.port_input.text())
        high_speed_port = int(self.high_speed_port_input.text())

        ethernetConfig = LJXAwrap.LJX8IF_ETHERNET_CONFIG()
        ethernetConfig.abyIpAddress = (ctypes.c_ubyte * 4)(*map(int, ip_parts))
        ethernetConfig.wPortNo = port

        res = LJXAwrap.LJX8IF_EthernetOpen(self.device_id, ethernetConfig)
        if res == 0:
            QMessageBox.information(self, "Success", "通信成功")
        else:
            QMessageBox.critical(self, "Error", "通信失败")


    def stop_refresh(self):
        self.timer.stop()

    def start_record(self):
        self.recording = True

    def stop_record(self):
        self.recording = False

    def select_save_path(self):
        self.save_path = QFileDialog.getSaveFileName(self, "选择保存地址", "", "Excel Files (*.xlsx)")[0]
        self.save_path_display.setText(self.save_path)

    def update_plot(self):
        if image_available:
            x = np.linspace(0, 3200, 3200)
            y = z_val[:3200]
            self.canvas.plot(x, y)

            fft_y = np.fft.fft(y)
            fft_x = np.fft.fftfreq(len(y))
            self.canvas_fft.plot(fft_x, np.abs(fft_y))

            if self.recording:
                self.data_buffer.append(y)
                if len(self.data_buffer) >= 500:
                    self.save_data_to_excel()
                    self.data_buffer = []

    def save_data_to_excel(self):
        if self.save_path:
            df = pd.DataFrame(self.data_buffer)
            df.to_excel(self.save_path, index=False, header=False, mode='a')

def callback_s_a(p_header, p_height, xpointnum, profnum, notify, user):
    global ysize_acquired
    global image_available
    global z_val


    if (notify == 0) or (notify == 0x10000):
        if profnum != 0:
            if image_available is False:
                z_val[:xpointnum * profnum] = p_height[:xpointnum * profnum]
                ysize_acquired = profnum
                image_available = True
    return

def main():
    app = QApplication(sys.argv)
    mainWindow = MainApp()
    mainWindow.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()