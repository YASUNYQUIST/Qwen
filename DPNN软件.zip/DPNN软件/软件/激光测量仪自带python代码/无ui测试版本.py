
import sys
import numpy as np
from PySide2.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QMessageBox, QSizePolicy
from PySide2.QtCore import QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import time
# def callback_s_a(p_header, p_height, p_lumi, luminance_enable, xpointnum, profnum, notify, user):
#     global image_available, z_val, callback_counter, clear_memory_counter, device_id
#
#     try:
#         callback_counter += 1
#         clear_memory_counter += 1
#         print(f"Callback executed successfully. Count: {callback_counter}")
#
#         if callback_counter > 1000:  # Limit callback executions to avoid infinite loop
#             print("Callback limit reached, stopping further processing.")
#             return
#
#         if (notify == 0) or (notify == 0x10000):
#             if profnum != 0:
#                 z_val = [height / 100000.0 for height in p_height[:xpointnum]]
#                 image_available = True
#                 print(f"New data received. z_val length: {len(z_val)}")
#
#
#                 # # 每10次清除一次内存缓存
#                 # if clear_memory_counter >= 10:
#                 #     print("Attempting to clear memory after callback...")
#                 #     res = LJXAwrap.LJX8IF_ClearMemory(device_id)
#                 #     if res != 0:
#                 #         print(f"Failed to clear memory after callback. Error code: {res}")
#                 #     clear_memory_counter = 0  # 重置计数器
#     except Exception as e:
#         print(f"Exception occurred in callback: {e}")

import LJXAwrap
import ctypes

# 全局变量
image_available = False #图像状态
z_val = [] #z值坐标
callback_counter = 0 #采集到的轮廓个数
clear_memory_counter = 0  # 增加一个计数器，用于控制清除缓存的频率
device_id = 0  # 全局变量 device_id


def callback_s_a(p_header, p_height, p_lumi, luminance_enable, xpointnum, profnum, notify, user):
    global image_available,callback_counter,clear_memory_counter
    global z_val
    clear_memory_counter = 0

    if (notify == 0) or (notify == 0x10000):
        if profnum != 0:
            z_val = [height / 100000.0 for height in p_height[:xpointnum]]  # 将高度转换为毫米
            callback_counter += 1
            print(f"Callback executed successfully. Count: {callback_counter}")
            print(f"New data received. z_val length: {len(z_val)}")
            image_available = True
            # # 每隔50次调用清理缓存
            # clear_memory_counter += 1
            # if clear_memory_counter % 2 == 0:
            #     import gc
            #     gc.collect()  # 强制进行垃圾回收
            #     print("Garbage collection performed.")
    return

ip_address = [192, 168, 0, 1]
port = 24691
high_speed_port = 24692
ethernetConfig = LJXAwrap.LJX8IF_ETHERNET_CONFIG()
ethernetConfig.abyIpAddress = (ctypes.c_ubyte * 4)(*ip_address)
ethernetConfig.wPortNo = port
print(f"Attempting to open Ethernet communication with IP: {ip_address} and port: {port}")
res = LJXAwrap.LJX8IF_EthernetOpen(device_id, ethernetConfig)
if res != 0:
   print(f"Failed to connect to the controller. Error code: {res}")
my_callback_s_a = LJXAwrap.LJX8IF_CALLBACK_SIMPLE_ARRAY(callback_s_a)
res = LJXAwrap.LJX8IF_InitializeHighSpeedDataCommunicationSimpleArray(
                device_id,
                ethernetConfig,
                high_speed_port,
                my_callback_s_a,
                1,
                0
            )
if res != 0:
   print(f"Failed to initialize high-speed communication. Error code: {res}")
req = LJXAwrap.LJX8IF_HIGH_SPEED_PRE_START_REQ()
req.bySendPosition = 2
profinfo = LJXAwrap.LJX8IF_PROFILE_INFO()
res = LJXAwrap.LJX8IF_PreStartHighSpeedDataCommunication(
                device_id,
                req,
                profinfo
            )
if res != 0:
   print(f"Failed to pre-start high-speed communication. Error code: {res}")

xsize = profinfo.wProfileDataCount
z_val = [0] * xsize
res = LJXAwrap.LJX8IF_StartHighSpeedDataCommunication(device_id)
if res != 0:
   print(f"Failed to start high-speed communication. Error code: {res}")
#
#
# res = LJXAwrap.LJX8IF_StartMeasure(device_id)
# if res != 0:
#    print(f"Failed to start measure. Error code: {res}")
# print("Initialization of communication successful.")
#
plt.ion()
fig, ax = plt.subplots()
x_vals = [i * 0.025 for i in range(xsize)]  # 将x轴转换为毫米
line, = ax.plot(x_vals, z_val)
plt.xlabel('Distance (mm)')
plt.ylabel('Height (mm)')
plt.title('Real-time Height Profile')

try:
    while True:
        start_time = time.time()
        if image_available:
            line.set_ydata(z_val)
            ax.relim()
            ax.autoscale_view()
            plt.draw()
            plt.pause(0.001)
            image_available = False  # 重置标志位以接收下一组数据
        end_time = time.time()
        elapsed_time = end_time - start_time
        sleep_time = max(0, 0.01 - elapsed_time)  # 保证刷新率为100Hz
        time.sleep(sleep_time)
except KeyboardInterrupt:
    print("Data collection stopped by user.")
