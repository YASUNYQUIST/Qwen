import numpy as np
import matplotlib.pyplot as plt


# 生成0到8之间均匀分布的3200个X值
x_data = np.linspace(0, 8, 3200)

# 计算对应的Y值
y_data  = -x_data**2 + 8 * x_data

# 进行快速傅里叶变换
fft_result = np.fft.fft(y_data)

# 计算频率轴
n = len(y_data)
freqs = np.fft.fftfreq(n)

# 仅分析正频率部分
positive_freqs = freqs[:n//2]
positive_fft_result = np.abs(fft_result[:n//2])

# 画出频域图
plt.figure(figsize=(12, 6))
plt.plot(positive_freqs, positive_fft_result)
plt.xlabel('Frequency')
plt.ylabel('Amplitude')
plt.title('Frequency Domain')
plt.show()

plt.figure(figsize=(12, 6))
plt.plot(x_data, y_data )
plt.xlabel('x')
plt.ylabel('y')
plt.show()
# 检测高频成分
threshold = np.mean(positive_fft_result) + 2 * np.std(positive_fft_result)
high_freq_indices = positive_fft_result > threshold

# 打印高频成分
print("High frequency components detected at indices:", np.where(high_freq_indices))


