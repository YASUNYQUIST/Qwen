import LJXAwrap
import ctypes
import sys
import time
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from PySide2.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox, QPushButton, QLineEdit, QWidget, QVBoxLayout, QSizePolicy
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import QFile, QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# 全局变量
image_available = False
z_val = []
recording = False
data_buffer = []
save_path = ""

# 缎带轮廓显示窗口设置
class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.updateGeometry()

    def plot(self, x, y):
        self.axes.clear()
        self.axes.plot(x, y)
        self.figs.canvas.draw()
        self.figs.canvas.flush_events()

# 主窗口初始化
class MainApp(QMainWindow):
    def __init__(self):
        super(MainApp, self).__init__()
        self.initUI()

    def initUI(self):
        # 载入ui界面
        ui_file = QFile("untitled.ui")
        if not ui_file.exists():
            print("UI file not found")
            sys.exit(-1)
        ui_file.open(QFile.ReadOnly)
        loader = QUiLoader()
        self.window = loader.load(ui_file, self)
        ui_file.close()

        if self.window is None:
            print("Failed to load the UI file.")
            sys.exit(-1)

        # 初始化通信按钮
        self.init_communication_btn = self.window.findChild(QPushButton, "pushButton")
        # 开启实时缎带轮廓刷新按钮
        self.start_refresh_btn = self.window.findChild(QPushButton, "pushButton_2")
        # 关闭实时缎带轮廓刷新按钮
        self.stop_refresh_btn = self.window.findChild(QPushButton, "pushButton_3")
        # 开启记录缎带轮廓按钮
        self.start_record_btn = self.window.findChild(QPushButton, "pushButton_4")
        # 关闭记录缎带轮廓按钮
        self.stop_record_btn = self.window.findChild(QPushButton, "pushButton_5")
        # 选择轮廓数据保存地址按钮
        self.select_save_path_btn = self.window.findChild(QPushButton, "pushButton_18")

        if not all([self.init_communication_btn, self.start_refresh_btn, self.stop_refresh_btn, self.start_record_btn, self.stop_record_btn, self.select_save_path_btn]):
            print("One or more buttons not found in the UI file.")
            sys.exit(-1)

        # 将函数与按钮关联
        self.init_communication_btn.clicked.connect(self.init_communication)
        self.start_refresh_btn.clicked.connect(self.start_refresh)
        self.stop_refresh_btn.clicked.connect(self.stop_refresh)
        self.start_record_btn.clicked.connect(self.start_record)
        self.stop_record_btn.clicked.connect(self.stop_record)
        self.select_save_path_btn.clicked.connect(self.select_save_path)

        # 输入框
        self.ip_part_1 = self.window.findChild(QLineEdit, "lineEdit")
        self.ip_part_2 = self.window.findChild(QLineEdit, "lineEdit_2")
        self.ip_part_3 = self.window.findChild(QLineEdit, "lineEdit_3")
        self.ip_part_4 = self.window.findChild(QLineEdit, "lineEdit_4")
        self.port_input = self.window.findChild(QLineEdit, "lineEdit_12")
        self.high_speed_port_input = self.window.findChild(QLineEdit, "lineEdit_13")
        self.save_path_display = self.window.findChild(QLineEdit, "lineEdit_10")

        # 创建缎带轮廓显示窗口
        self.canvas = PlotCanvas(self.window.findChild(QWidget, "widget_1"), width=5, height=4)

        layout1 = QVBoxLayout(self.window.findChild(QWidget, "widget_1"))
        layout1.addWidget(self.canvas)
        layout1.setStretch(0, 1)

        self.setCentralWidget(self.window)
        self.timer = QTimer()
        self.device_id = 0  # 初始化 device_id

    def init_communication(self):
        try:
            print("Initializing communication...")
            ip_parts = [self.ip_part_1.text(), self.ip_part_2.text(), self.ip_part_3.text(), self.ip_part_4.text()]
            port = int(self.port_input.text())
            high_speed_port = int(self.high_speed_port_input.text())

            ethernetConfig = LJXAwrap.LJX8IF_ETHERNET_CONFIG()
            ethernetConfig.abyIpAddress = (ctypes.c_ubyte * 4)(*map(int, ip_parts))
            ethernetConfig.wPortNo = port

            print(f"Attempting to open Ethernet communication with IP: {ip_parts} and port: {port}")
            res = LJXAwrap.LJX8IF_EthernetOpen(self.device_id, ethernetConfig)
            if res == 0:
                QMessageBox.information(self, "Success", "通信成功")
                print("Ethernet communication opened successfully.")
            else:
                QMessageBox.critical(self, "Error", f"通信失败: 错误代码 {res}")
                print(f"Ethernet communication failed with error code: {res}")
                return

            my_callback_s_a = LJXAwrap.LJX8IF_CALLBACK_SIMPLE_ARRAY(callback_s_a)
            print("Initializing high-speed data communication...")
            res = LJXAwrap.LJX8IF_InitializeHighSpeedDataCommunicationSimpleArray(
                self.device_id,
                ethernetConfig,
                high_speed_port,
                my_callback_s_a,
                1,
                0
            )
            if res != 0:
                QMessageBox.critical(self, "Error", f"初始化高速通信失败: 错误代码 {res}")
                print(f"Failed to initialize high-speed communication with error code: {res}")
                return

            req = LJXAwrap.LJX8IF_HIGH_SPEED_PRE_START_REQ()
            req.bySendPosition = 2
            profinfo = LJXAwrap.LJX8IF_PROFILE_INFO()
            print("Pre-starting high-speed data communication...")
            res = LJXAwrap.LJX8IF_PreStartHighSpeedDataCommunication(
                self.device_id,
                req,
                profinfo
            )
            if res != 0:
                QMessageBox.critical(self, "Error", f"预启动高速通信失败: 错误代码 {res}")
                print(f"Failed to pre-start high-speed communication with error code: {res}")
                return

            xsize = profinfo.wProfileDataCount
            global z_val
            z_val = [0] * xsize

            global image_available
            image_available = False
            print("Starting high-speed data communication...")
            res = LJXAwrap.LJX8IF_StartHighSpeedDataCommunication(self.device_id)
            if res != 0:
                QMessageBox.critical(self, "Error", f"启动高速通信失败: 错误代码 {res}")
                print(f"Failed to start high-speed communication with error code: {res}")
                return

            print("Initialization of communication successful.")
        except Exception as e:
            print(f"Exception occurred during initialization: {e}")

    def start_refresh(self):
        try:
            print("Starting refresh...")
            res = LJXAwrap.LJX8IF_StartMeasure(self.device_id)
            if res != 0:
                print(f"Failed to start measure with error code: {res}")
            self.timer.timeout.connect(self.update_plot)
            self.timer.start(10)
            print("Refresh started.")
        except Exception as e:
            print(f"Exception occurred during start_refresh: {e}")

    def stop_refresh(self):
        try:
            print("Stopping refresh...")
            self.timer.stop()
            self.timer.timeout.disconnect(self.update_plot)
            res = LJXAwrap.LJX8IF_StopMeasure(self.device_id)
            if res != 0:
                print(f"Failed to stop measure with error code: {res}")
            print("Refresh stopped.")
        except Exception as e:
            print(f"Exception occurred during stop_refresh: {e}")

    def start_record(self):
        global recording
        print("Starting recording...")
        recording = True

    def stop_record(self):
        global recording, data_buffer, save_path
        print("Stopping recording...")
        recording = False
        if save_path and data_buffer:
            print("Saving recorded data...")
            self.save_data_to_excel()
            data_buffer = []
            QMessageBox.information(self, "Info", "缎带轮廓数据已存储")
            print("Recorded data saved.")

    def select_save_path(self):
        global save_path
        save_path = QFileDialog.getSaveFileName(self, "选择保存地址", "", "Excel Files (*.xlsx)")[0]
        self.save_path_display.setText(save_path)
        print(f"Selected save path: {save_path}")

    def update_plot(self):
        global z_val, image_available

        if image_available:
            x = np.linspace(0, len(z_val), len(z_val))
            self.canvas.plot(x, z_val)
            image_available = False
            print("Plot updated.")

    def record_data(self):
        global z_val, data_buffer, save_path
        data_buffer.append(z_val[:])
        if len(data_buffer) >= 500:
            print("Buffer full, saving data to Excel...")
            self.save_data_to_excel()
            data_buffer = []

    def save_data_to_excel(self):
        global save_path, data_buffer

        if save_path:
            df = pd.DataFrame(data_buffer)
            df.to_excel(save_path, index=False, header=False, mode='a')
            print("Data saved to Excel.")

def callback_s_a(p_header, p_height, p_lumi, luminance_enable, xpointnum, profnum, notify, user):
    global image_available, z_val, recording

    try:
        if (notify == 0) or (notify == 0x10000):
            if profnum != 0:
                z_val = [height / 100000.0 for height in p_height[:xpointnum]]
                image_available = True
                if recording:
                    main_app.record_data()  # 在这里调用record_data进行记录
                print("Callback executed successfully.")
    except Exception as e:
        print(f"Exception in callback_s_a: {e}")


def main():
    global main_app
    app = QApplication(sys.argv)
    main_app = MainApp()
    main_app.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()

