import LJXAwrap
import ctypes
import sys
import time
import matplotlib.pyplot as plt

# 全局变量
image_available = False
z_val = []

def callback_s_a(p_header, p_height, p_lumi, luminance_enable, xpointnum, profnum, notify, user):
    global image_available
    global z_val

    if (notify == 0) or (notify == 0x10000):
        if profnum != 0:
            z_val = [height / 100000.0 for height in p_height[:xpointnum]]  # 将高度转换为毫米
            image_available = True
    return

def main():
    global image_available
    global z_val

    # 配置参数
    device_id = 0
    ysize = 1  # 只采集一行数据
    ip_address = [192, 168, 0, 1]
    port = 24691
    high_speed_port = 24692

    # 初始化以太网配置
    ethernetConfig = LJXAwrap.LJX8IF_ETHERNET_CONFIG()
    ethernetConfig.abyIpAddress = (ctypes.c_ubyte * 4)(*ip_address)
    ethernetConfig.wPortNo = port

    # 打开以太网连接
    res = LJXAwrap.LJX8IF_EthernetOpen(device_id, ethernetConfig)
    if res != 0:
        print("Failed to connect to the controller.")
        sys.exit()

    # 初始化高速通信
    my_callback_s_a = LJXAwrap.LJX8IF_CALLBACK_SIMPLE_ARRAY(callback_s_a)
    res = LJXAwrap.LJX8IF_InitializeHighSpeedDataCommunicationSimpleArray(
        device_id,
        ethernetConfig,
        high_speed_port,
        my_callback_s_a,
        ysize,
        0
    )
    if res != 0:
        print("Failed to initialize high-speed communication.")
        sys.exit()

    # 预启动高速通信
    req = LJXAwrap.LJX8IF_HIGH_SPEED_PRE_START_REQ()
    req.bySendPosition = 2
    profinfo = LJXAwrap.LJX8IF_PROFILE_INFO()
    res = LJXAwrap.LJX8IF_PreStartHighSpeedDataCommunication(
        device_id,
        req,
        profinfo
    )
    if res != 0:
        print("Failed to pre-start high-speed communication.")
        sys.exit()

    # 分配内存
    xsize = profinfo.wProfileDataCount
    z_val = [0] * xsize

    # 开始高速通信
    image_available = False
    res = LJXAwrap.LJX8IF_StartHighSpeedDataCommunication(device_id)
    if res != 0:
        print("Failed to start high-speed communication.")
        sys.exit()

    # 开始测量
    LJXAwrap.LJX8IF_StartMeasure(device_id)

    # 初始化绘图
    plt.ion()
    fig, ax = plt.subplots()
    x_vals = [i * 0.025 for i in range(xsize)]  # 将x轴转换为毫米
    line, = ax.plot(x_vals, z_val)
    plt.xlabel('Distance (mm)')
    plt.ylabel('Height (mm)')
    plt.title('Real-time Height Profile')

    # 实时数据采集和绘图
    try:
        while True:
            start_time = time.time()
            if image_available:
                line.set_ydata(z_val)
                ax.relim()
                ax.autoscale_view()
                plt.draw()
                plt.pause(0.001)
                image_available = False  # 重置标志位以接收下一组数据
            end_time = time.time()
            elapsed_time = end_time - start_time
            sleep_time = max(0, 0.01 - elapsed_time)  # 保证刷新率为100Hz
            time.sleep(sleep_time)
    except KeyboardInterrupt:
        print("Data collection stopped by user.")

    # 停止高速通信
    LJXAwrap.LJX8IF_StopHighSpeedDataCommunication(device_id)
    LJXAwrap.LJX8IF_FinalizeHighSpeedDataCommunication(device_id)
    LJXAwrap.LJX8IF_CommunicationClose(device_id)

    plt.ioff()
    plt.show()

if __name__ == "__main__":
    main()
