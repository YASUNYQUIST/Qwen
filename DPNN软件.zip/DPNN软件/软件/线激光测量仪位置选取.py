import numpy as np
import matplotlib.pyplot as plt
import math

# 角度从0度到30度（每1度）
degrees = np.arange(0, 16, 1)
radians = np.radians(degrees)

# 计算函数值
# f1_values = (0.18 * np.sin(radians) + 0.245 * np.cos(radians))/(0.18 + 0.245 * np.sin(radians) - 0.18 * np.cos(radians))
# f1_values = np.arctan(1/f1_values)*180/math.pi


import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
import math

def equations(vars, theta, R):
    x, y = vars
    eq1 = (x - 0.18 * np.sin(theta))**2 + (y - (0.18 - 0.18 * np.cos(theta)))**2 - 0.245**2
    eq2 = x**2 + (y - R)**2 - R**2
    return [eq1, eq2]

# 定义R值
#R = 5 / 3 * (1 + 0.09)
R = 5 / 3 * (0.5*0.5+ 0.09)  # 可以切换R值来查看另一个曲线

# 初始化存储解的列表
x_values = []
y_values = []

# 初始猜测值
initial_guess = [0.1, 0.1]

# 角度从0度到30度（每1度）
for degree in range(0, 16):
    theta = np.radians(degree)
    solution = fsolve(equations, initial_guess, args=(theta, R))
    x, y = solution
    # 只记录x大于0的解
    if x > 0:
        x_values.append(x)
        y_values.append(y)
    else:
        # 重新设定初始猜测值，以确保找到 x > 0 的解
        initial_guess = [1.0, 1.0]
        solution = fsolve(equations, initial_guess, args=(theta, R))
        x, y = solution
        if x > 0:
            x_values.append(x)
            y_values.append(y)
        else:
            print(f"警告：在角度{degree}度下未找到 x > 0 的解")


# 计算角度值
angles = [np.degrees(np.arctan2(y, x)) for x, y in zip(x_values, y_values)]

# 绘制坐标点变化曲线
plt.plot(range(0, 16), angles, label='Angle (degrees)')
plt.xlabel('Degree')
plt.ylabel('Angle')

# 绘制曲线
plt.plot(degrees, f1_values, label='θ')
plt.xlabel('Degree')
plt.ylabel('Function values')
plt.legend()
plt.title(f'Angle vs. Degree (R={R:.2f})')
plt.show()
