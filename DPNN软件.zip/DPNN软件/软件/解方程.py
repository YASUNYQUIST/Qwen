import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt


def equations(vars, theta, R):
    x, y = vars
    left_side = (x - 0.18 * np.sin(theta)) ** 2 + (y - 0.18 * (1 - np.cos(theta))) ** 2 - 0.245 ** 2
    right_side = x ** 2 + y ** 2 - 2 * R * y
    return [left_side ,right_side]

def equations_1(vars, theta, R):
    x, y = vars
    left_side = (x - 0.18 * np.sin(theta)) ** 2 + (y - 0.18 * (1 - np.cos(theta))) ** 2 - 0.353 ** 2
    right_side = x ** 2 + y ** 2 - 2 * R * y
    return [left_side ,right_side]


# 定义R值
R1 = 5 / 3 * (1*1 + 0.09)

# 初始化存储解的列表
x_values_R1 = []
y_values_R1 = []
x_values_R2 = []
y_values_R2 = []
f1_values = []
f2_values = []

# 初始猜测值
initial_guess = [0.1, 0.1]

# 角度从0度到30度（每1度）
for degree in range(0, 16):
    theta = np.radians(degree)

    # 求解第一个R值对应的x和y
    solution1 = fsolve(equations, initial_guess, args=(theta, R1))
    solution2 = fsolve(equations_1, initial_guess, args=(theta, R1))
    x1, y1 = solution1
    x2, y2 = solution2
    if x1 > 0:
        x_values_R1.append(x1)
        y_values_R1.append(y1)
    if x2 > 0:
        x_values_R2.append(x2)
        y_values_R2.append(y2)
    f1 = 0.18 * np.sin(theta) + 0.353 * np.cos(theta)
    f2 = 0.353 * np.sin(theta) + 0.18 * (1 - np.cos(theta))
    f1_values.append(f1)
    f2_values.append(f2)


# 绘制坐标点变化曲线
plt.figure(figsize=(12, 6))
# 绘制方程 x^2 + (y - R)^2 = R^2 的圆
theta_circle = np.linspace(0, 2 * np.pi, 100)
x_circle = R1 * np.cos(theta_circle)
y_circle = R1 * np.sin(theta_circle) + R1
x_circle_2 = 0.18 * np.cos(theta_circle)
y_circle_2 = 0.18 * np.sin(theta_circle) + 0.18
plt.plot(x_circle_2, y_circle_2, 'g--', label='center (0, 0.18), radius 0.18')

# 只保留 x 在 [0, R1] 且 y 在 [0, 0.3] 范围内的部分
mask = (x_circle >= 0) & (x_circle <= R1) & (y_circle >= 0) & (y_circle <= 0.3)
plt.plot(x_circle[mask], y_circle[mask], 'b-', label='x^2 + (y - R)^2 = R^2')
# plt.plot(x_values_R1, y_values_R1, 'o-', label='right')
plt.plot(f1_values, f2_values, 'o-', label='max')
plt.plot(x_values_R2, y_values_R2, 'o-', label='left')
plt.xlabel('x values')
plt.ylabel('y values')
plt.title('min')
# plt.axhline(0, color='black',linewidth=0.5)
# plt.axvline(0, color='black',linewidth=0.5)
# plt.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
plt.legend()
plt.grid(True)
plt.show()