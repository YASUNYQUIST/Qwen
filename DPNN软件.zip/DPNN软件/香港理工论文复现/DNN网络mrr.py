import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from scipy.interpolate import BSpline
import numpy as np
import matplotlib.pyplot as plt

# 加载数据
data = np.array([
    [1, 0, 0.1, 2, 7.39],
    [0, 0.05, 0.1, 2, 10.11],
    [0, 0.1, 0.1, 2, 9.32],
    [0, 0.25, 0.1, 2, 11.55],
    [0, 0.5, 0.1, 2, 9.95],
    [0, 0.75, 0.1, 2, 12.2],
    [0, 1, 0.1, 2, 11.12],
    [1, 0.1, 0.1, 2, 11.66],
    [1, 0.25, 0.1, 2, 11.77],
    [1, 0.5, 0.1, 2, 12.37],
    [1, 0.75, 0.1, 2, 11.02],
    [1, 1, 0.1, 2, 11.34],
    [0, 0.05, 0.06, 2, 6.27],
    [0, 0.05, 0.08, 2, 8.53],
    [0, 0.05, 0.12, 2, 13.52],
    [0, 0.05, 0.15, 2, 15.67],
    [0, 0.05, 0.16, 2, 16.44],
    [0, 0.05, 0.18, 2, 17.53],
    [0, 0.05, 0.19, 2, 16.53],
    [0, 0.05, 0.2, 2, 17.98],
    [0, 0.05, 0.21, 2, 21.46],
    [0, 0.05, 0.22, 2, 20.87],
    [0, 0.05, 0.16, 0.5, 4.55],
    [0, 0.05, 0.16, 1, 4.55],
    [0, 0.05, 0.16, 1.3, 11.49],
    [0, 0.05, 0.16, 1.6, 12.96],
    [0, 0.05, 0.16, 2.3, 18.77],
    [0, 0.05, 0.16, 2.5, 18.09],
    [0, 0.05, 0.16, 3, 14.14],
    [0, 0.05, 0.16, 4, 17.58],
    [0, 0.05, 0.16, 5, 19.27]
])

# 提取特征和目标值
X = data[:, :-1]
y = data[:, -1]

# 数据标准化
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)

# B样条变换
degree = 2  # B样条的度数
n_knots = 3 # 节点数量

# 为每个特征生成B样条基函数
splines = []
for i in range(X_normalized.shape[1]):
    x = X_normalized[:, i]
    t = np.linspace(0, 1, n_knots + degree + 1)  # 生成节点向量
    splines.append(BSpline(t, np.eye(len(t)), degree))

# 计算B样条基函数值
X_spline = np.hstack([spl(x) for spl, x in zip(splines, X_normalized.T)])

# 划分数据集
X_train, X_val, y_train, y_val = train_test_split(X_spline, y, test_size=0.1, random_state=39)

# 转换为 PyTorch 张量
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.float32).view(-1, 1)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
y_val_tensor = torch.tensor(y_val, dtype=torch.float32).view(-1, 1)
X_tensor = torch.tensor(X_spline, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)

# 构建 DNN 模型
class DNN(nn.Module):
    def __init__(self):
        super(DNN, self).__init__()
        self.hidden1 = nn.Linear(X_train.shape[1], 128)
        self.hidden2 = nn.Linear(128, 64)
        self.hidden3 = nn.Linear(64, 32)
        self.hidden4 = nn.Linear(32, 16)
        self.hidden5 = nn.Linear(16, 8)
        self.hidden6 = nn.Linear(8, 4)
        self.output = nn.Linear(4, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.hidden1(x))
        x = self.relu(self.hidden2(x))
        x = self.relu(self.hidden3(x))
        x = self.relu(self.hidden4(x))
        x = self.relu(self.hidden5(x))
        x = self.relu(self.hidden6(x))
        x = self.output(x)
        return x

model = DNN()

# 损失函数和优化器
criterion = nn.L1Loss()  # 使用 MAE 作为损失函数
optimizer = optim.NAdam(model.parameters(), lr=0.001)  # 使用 NAdam 优化器

# 训练模型
num_epochs = 200
batch_size = 1

train_losses = []
val_losses = []

for epoch in range(num_epochs):
    model.train()
    permutation = torch.randperm(X_train_tensor.size()[0])
    running_loss = 0.0
    for i in range(0, X_train_tensor.size()[0], batch_size):
        optimizer.zero_grad()
        indices = permutation[i:i+batch_size]
        batch_x, batch_y = X_train_tensor[indices], y_train_tensor[indices]

        outputs = model(batch_x)
        loss = criterion(outputs, batch_y)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()

    epoch_loss = running_loss / X_train_tensor.size()[0]
    train_losses.append(epoch_loss)

    model.eval()
    with torch.no_grad():
        val_outputs = model(X_val_tensor)
        val_loss = criterion(val_outputs, y_val_tensor).item()
    val_losses.append(val_loss)

    # 打印训练过程中的损失
    print(f'Epoch [{epoch+1}/{num_epochs}], Train Loss: {epoch_loss:.4f}, Val Loss: {val_loss:.4f}')

# 保存最终的模型权重
final_model_path = 'best_model.pth'
torch.save(model.state_dict(), final_model_path)

# 加载最终的模型权重
model.load_state_dict(torch.load(final_model_path))

# 绘制训练和验证损失曲线
plt.figure(figsize=(10, 6))
plt.plot(range(num_epochs), train_losses, label='Train Loss')
plt.plot(range(num_epochs), val_losses, label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.title('Training and Validation Loss')
plt.savefig('training_validation_loss.png')
plt.show()

# 使用最终的权重进行预测
model.eval()
with torch.no_grad():
    y_pred_tensor = model(X_tensor)
y_pred = y_pred_tensor.numpy()

# 绘制实际 MRR 和预测 MRR 对比曲线图
plt.figure(figsize=(10, 6))
plt.plot(range(len(y)), y, 'b', label='Actual MRR')
plt.plot(range(len(y)), y_pred, 'r--', label='Predicted MRR')
plt.xlabel('Experiment Number')
plt.ylabel('MRR (0.001*mm^3/3min)')
plt.legend()
plt.title('Comparison of Actual and Predicted MRR')
plt.savefig('actual_vs_predicted_mrr.png')
plt.show()

