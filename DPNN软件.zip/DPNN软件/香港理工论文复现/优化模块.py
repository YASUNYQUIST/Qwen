import numpy as np
import torch
import torch.nn as nn
from scipy.optimize import differential_evolution
from skopt import gp_minimize
from skopt.space import Real
from scipy.interpolate import BSpline
from sklearn.preprocessing import MinMaxScaler

# 定义 DNN 模型架构
class DNN(nn.Module):
    def __init__(self, input_dim):
        super(DNN, self).__init__()
        self.hidden1 = nn.Linear(input_dim, 128)
        self.hidden2 = nn.Linear(128, 64)
        self.hidden3 = nn.Linear(64, 32)
        self.hidden4 = nn.Linear(32, 16)
        self.hidden5 = nn.Linear(16, 8)
        self.hidden6 = nn.Linear(8, 4)
        self.output = nn.Linear(4, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.hidden1(x))
        x = self.relu(self.hidden2(x))
        x = self.relu(self.hidden3(x))
        x = self.relu(self.hidden4(x))
        x = self.relu(self.hidden5(x))
        x = self.relu(self.hidden6(x))
        x = self.output(x)
        return x

# 加载模型
input_dim = 24  # 假设模型的输入维度为36
model = DNN(input_dim=input_dim)
model.load_state_dict(torch.load('best_model.pth'))
model.eval()

# 定义 B样条变换函数
def bspline_transform(x, degree=2, n_knots=3):
    t = np.linspace(0, 1, n_knots + degree + 1)
    spl = BSpline(t, np.eye(len(t)), degree)
    return np.hstack([spl(f) for f in x])

# 定义标准化器
scaler = MinMaxScaler()
scaler.fit(np.array([
    [0, 0, 0.16, 0.5],  # 参数的最小值
    [1, 1, 0.22, 5]     # 参数的最大值
]))

# 定义标准化函数
def normalize_params(params):
    return scaler.transform([params])[0]

# 定义目标函数
def objective(x):
    x = normalize_params(x)
    x = bspline_transform(x)
    x = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
    with torch.no_grad():
        return -model(x).item()

# 强制离散方向参数
def discrete_direction(params):
    params[0] = round(params[0])
    return params

# 修改后的目标函数，考虑Direction为0和1的情况
def objective_with_direction(x):
    x = normalize_params(x)
    x = bspline_transform(x)
    x = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
    with torch.no_grad():
        mrr_0 = -model(torch.cat([torch.tensor([[0]], dtype=torch.float32), x[:, 1:]], dim=1)).item()
        mrr_1 = -model(torch.cat([torch.tensor([[1]], dtype=torch.float32), x[:, 1:]], dim=1)).item()
    if mrr_0 > mrr_1:
        return mrr_0, 0
    else:
        return mrr_1, 1

# 定义优化目标函数，加入边界检查
def optimize_mrr(params):
    F, CR = params
    bounds = [(0, 1), (0, 1), (0.16, 0.22), (0.5, 5)]
    result = differential_evolution(lambda x: objective_with_direction(np.clip(x, [0, 0, 0.16, 0.5], [1, 1, 0.22, 5]))[0], bounds, strategy='best1bin', maxiter=30, popsize=20, recombination=CR, mutation=(F, 1))
    print(f"F: {F}, CR: {CR}, Best MRR: {result.fun}, Params: {result.x}")  # 添加诊断信息
    return result.fun

# 使用贝叶斯优化找到最佳 F 和 CR
space = [Real(0.1, 1, name='F'), Real(0.1, 1, name='CR')]
res_gp = gp_minimize(optimize_mrr, space, n_calls=50, random_state=42)

print("Best F:", res_gp.x[0])
print("Best CR:", res_gp.x[1])

# 使用最佳 F 和 CR 进行 MRR 优化
best_F = res_gp.x[0]
best_CR = res_gp.x[1]

bounds = [(0, 1), (0, 1), (0.16, 0.22), (0.5, 5)]
result = differential_evolution(lambda x: objective_with_direction(np.clip(x, [0, 0, 0.16, 0.5], [1, 1, 0.22, 5]))[0], bounds, strategy='best1bin', maxiter=100, popsize=20, recombination=best_CR, mutation=(best_F, 1))

best_params = result.x
best_params[0] = round(best_params[0])  # 确保方向参数为离散值0或1
best_mrr, best_direction = objective_with_direction(best_params)
best_params[0] = best_direction

# 打印结果
print("Best parameters:", best_params)
print("Best MRR:", -best_mrr)
