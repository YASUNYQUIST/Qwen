import numpy as np
import torch
import torch.nn as nn
from scipy.optimize import differential_evolution
from skopt import gp_minimize
from skopt.space import Real
from scipy.interpolate import BSpline
from sklearn.preprocessing import MinMaxScaler


# 定义 DNN 模型架构
class DNN(nn.Module):
    def __init__(self, input_dim):
        super(DNN, self).__init__()
        self.hidden1 = nn.Linear(input_dim, 128)
        self.hidden2 = nn.Linear(128, 64)
        self.hidden3 = nn.Linear(64, 32)
        self.hidden4 = nn.Linear(32, 16)
        self.hidden5 = nn.Linear(16, 8)
        self.hidden6 = nn.Linear(8, 4)
        self.output = nn.Linear(4, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.hidden1(x))
        x = self.relu(self.hidden2(x))
        x = self.relu(self.hidden3(x))
        x = self.relu(self.hidden4(x))
        x = self.relu(self.hidden5(x))
        x = self.relu(self.hidden6(x))
        x = self.output(x)
        return x


# 加载模型
input_dim = 24  # 假设模型的输入维度为24
model = DNN(input_dim=input_dim)
model.load_state_dict(torch.load('best_model.pth'))
model.eval()


# 定义 B样条变换函数
def bspline_transform(x, degree=2, n_knots=3):
    t = np.linspace(0, 1, n_knots + degree + 1)
    spl = BSpline(t, np.eye(len(t)), degree)
    return np.hstack([spl(f) for f in x])


# 定义标准化器
scaler = MinMaxScaler()
scaler.fit(np.array([
    [0, 0, 0.16, 0.5],  # 参数的最小值
    [1, 1, 0.22, 5]  # 参数的最大值
]))


# 定义标准化函数
def normalize_params(params):
    return scaler.transform([params])[0]


# 定义目标函数
def objective(x):
    x = normalize_params(x)
    x = bspline_transform(x)
    x = torch.tensor(x, dtype=torch.float32).unsqueeze(0)
    with torch.no_grad():
        return -model(x).item()


# 定义优化目标函数，加入边界检查
def optimize_mrr(params):
    F, CR = params
    bounds = [(0, 1), (0.16, 0.22), (0.5, 5)]

    def eval_params(x):
        x0 = np.array([0, x[0], x[1], x[2]])
        x1 = np.array([1, x[0], x[1], x[2]])
        mrr0 = objective(x0)
        mrr1 = objective(x1)
        return max(mrr0, mrr1)

    result = differential_evolution(
        eval_params,
        bounds,
        strategy='best1bin',
        maxiter=30,
        popsize=20,
        recombination=CR,
        mutation=(F, 1)
    )

    best_params = result.x
    mrr_with_0 = objective([0, best_params[0], best_params[1], best_params[2]])
    mrr_with_1 = objective([1, best_params[0], best_params[1], best_params[2]])

    if mrr_with_0 > mrr_with_1:
        best_params = [0, best_params[0], best_params[1], best_params[2]]
        best_mrr = mrr_with_0
    else:
        best_params = [1, best_params[0], best_params[1], best_params[2]]
        best_mrr = mrr_with_1

    print(f"F: {F}, CR: {CR}, Best MRR: {best_mrr}, Params: {best_params}")  # 添加诊断信息
    return -best_mrr


# 使用贝叶斯优化找到最佳 F 和 CR
space = [Real(0.1, 1, name='F'), Real(0.1, 1, name='CR')]
res_gp = gp_minimize(optimize_mrr, space, n_calls=25, random_state=42)

print("Best F:", res_gp.x[0])
print("Best CR:", res_gp.x[1])

# 使用最佳 F 和 CR 进行 MRR 优化
best_F = res_gp.x[0]
best_CR = res_gp.x[1]

bounds = [(0, 1), (0.16, 0.22), (0.5, 5)]


def eval_params(x):
    x0 = np.array([0, x[0], x[1], x[2]])
    x1 = np.array([1, x[0], x[1], x[2]])
    mrr0 = objective(x0)
    mrr1 = objective(x1)
    return max(mrr0, mrr1)


result = differential_evolution(
    eval_params,
    bounds,
    strategy='best1bin',
    maxiter=30,
    popsize=20,
    recombination=best_CR,
    mutation=(best_F, 1)
)

best_params = result.x
mrr_with_0 = objective([0, best_params[0], best_params[1], best_params[2]])
mrr_with_1 = objective([1, best_params[0], best_params[1], best_params[2]])

if mrr_with_0 > mrr_with_1:
    best_params = [0, best_params[0], best_params[1], best_params[2]]
    best_mrr = mrr_with_0
else:
    best_params = [1, best_params[0], best_params[1], best_params[2]]
    best_mrr = mrr_with_1

# 打印结果
print("Best parameters:", best_params)
print("Best MRR:", -best_mrr)

