import matplotlib
matplotlib.use("Qt5Agg")  # 声明使用pyqt5
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg  # pyqt5的画布
import matplotlib.pyplot as plt
import sys
from PySide2 import QtCore
from PySide2 import QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np


class MyMatplotlibFigure(FigureCanvasQTAgg):
    def __init__(self, width=10, heigh=10, dpi=100):
        plt.rcParams['figure.facecolor'] = 'r'
        plt.rcParams['axes.facecolor'] = 'b'
        self.figs = Figure(figsize=(width, heigh), dpi=dpi)
        super(MyMatplotlibFigure, self).__init__(self.figs)
        self.setParent(None)
        self.axes = self.figs.add_subplot(111)

    def mat_plot_drow_axes(self, t, s):
        self.axes.cla()
        self.axes.spines['top'].set_visible(False)
        self.axes.spines['right'].set_visible(False)
        self.axes.spines['left'].set_position(('data', 0))
        self.axes.plot(t, s, 'o-r', linewidth=0.5)
        self.figs.canvas.draw()
        self.figs.canvas.flush_events()


class MainDialogImgBW(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainDialogImgBW, self).__init__()
        self.setWindowTitle("显示matplotlib")
        self.setObjectName("widget")
        self.resize(800, 600)
        self.label = QtWidgets.QLabel(self)
        self.label.setGeometry(QtCore.QRect(0, 0, 800, 600))

        # 将画布放置在一个QWidget内
        container = QtWidgets.QWidget(self)
        self.canvas = MyMatplotlibFigure(width=5, heigh=4, dpi=100)
        layout = QtWidgets.QVBoxLayout(container)
        layout.addWidget(self.canvas)

        self.plotcos()

        self.hboxlayout = QtWidgets.QHBoxLayout(self.label)
        self.hboxlayout.addWidget(container)

    def plotcos(self):
        t = np.arange(0.0, 5.0, 0.01)
        s = np.cos(2 * np.pi * t)
        self.canvas.mat_plot_drow_axes(t, s)
        self.canvas.figs.suptitle("sin")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    main = MainDialogImgBW()
    main.show()
    sys.exit(app.exec_())
