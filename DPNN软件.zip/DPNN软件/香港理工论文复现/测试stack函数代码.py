import math
import sys  # 导入sys模块
import types

import matplotlib.pyplot as plt
import numpy as np
import scipy.optimize as optimize

sys.setrecursionlimit(100000)  # 将默认的递归深度修改为3000
plt.figure()

s=11.31
# 计算角度为s度的正弦值
angle_rad = math.radians(s)  # 将角度转换为弧度
sin_value = math.sin(angle_rad)

# 计算角度为s度的余弦值
angle_rad = math.radians(s)
cos_value = math.cos(angle_rad)

R0=2500
c=1/R0
k=-1
D=1000
# xz=input("请输入加工坐标系中x轴原点坐标:")
# xz=float(xz)
xz=500
# zz=input("请输入加工坐标系中z轴原点坐标：")
# zz=float(zz)
zz=50

# 计算需要的浮点数
term=1-c*zz*(1+k)
# 确保 term 是浮点数
if isinstance(term, list):
    term = term[0]  # 如果 term 是列表，提取第一个元素
# 计算 f
f=2*cos_value*term+2*c*xz*sin_value

j=c*k*2*sin_value*cos_value
l=4*c*(1+k*cos_value**2)
m=c*xz**2-2*zz+c*zz**2*(1+k)
n=2*c*xz*cos_value-2*sin_value*term
o=c*(1+k*sin_value**2)
p=2*c*(1+k*cos_value**2)
# R=5000 #初始搜索半径


class advance_retreat_method(object):
    """
    obj_func 为需要寻找单峰区间的目标函数
    x0为给定的初始点
    h0搜寻步长
    """

    def __init__(self, obj_func, x0=R0, h0=0.01):
        self.h = h0
        self.obj_func = obj_func
        self.x1 = x0
        self.x2 = x0 + h0
        self.x3 = 0
        self.y1 = 0
        self.y2 = 0
        self.y3 = 0

    # 1、计算函数值
    def func_value(self):
        self.y1 = self.obj_func(self.x1)
        self.y2 = self.obj_func(self.x2)
        plt.plot([self.x1, self.x2], [self.y1, self.y2], marker="*", color="red", markersize=15)

    # 2、比较函数值大小
    def compare_value(self):
        if self.y1 < self.y2:
            self.h = -self.h
            a = self.x1
            b = self.y1
            self.x1 = self.x2
            self.y1 = self.y2
            self.x2 = a
            self.y2 = b
        else:
            self.h = self.h

    # 3、计算y3
    def cal_y3(self):
        self.x3 = self.x2 + self.h
        self.y3 = self.obj_func(self.x2 + self.h)
        plt.plot([self.x2, self.x3], [self.y2, self.y3], marker="o", color="blue")

    # 4、比较y3与y2后判断是否输出单峰区间
    def get_interval(self):
        if self.y3 > self.y2:
            if self.x1 < self.x3:
                yield [self.x1, self.x3]
            else:
                yield [self.x3, self.x1]
        else:
            self.x1 = self.x2
            self.y1 = self.y2
            self.x2 = self.x3
            self.y2 = self.y3
            self.cal_y3()
            yield self.get_interval()
    def tramp(self,gen):
        g=gen()
        while isinstance(g, types.GeneratorType):
            g = g.__next__()
        return g
    # 5、统筹运行
    def run(self):
        # 1、计算y1和y2
        self.func_value()
        # 2、比较函数值大小
        self.compare_value()
        # 3、计算y3
        self.cal_y3()
        # 4 比较y3与y2后判断是否输出单峰区间
        result = self.tramp(self.get_interval)
        return result

class One_Search(object):
    def __init__(self,R):
        self.R=R

    def find_a(self,x): # 寻找一定R值下的a值
    # 计算
        sqrt_term=np.sqrt((j*x-f)**2-l*(m+n*x+o*x**2))
        result=(f-j*x-sqrt_term)/p+np.sqrt(self.R**2-x**2)
        return result
    #return [f-j*x-np.sqrt[(j*x-f)**2-l*(m+n*x+o*x**2)]]/p+np.sqrt(self.R**2-x**2)

    def Calcu_a(self):   #  计算a的值
        maximum=optimize.fminbound(lambda x:-self.find_a(x),0,D/2)
        endpoint_left=self.find_a(0)
        endpoint_right=self.find_a(D/2)
        a=self.find_a(maximum)
        if a<endpoint_left:
            a=endpoint_left
        if a<endpoint_right:
            a=endpoint_right
        if a>=self.R:
             return a
        else :
             return self.R

    def find_asphericity(self,x): # 寻找（R，a）情况下的最大非球面度点
        a=self.Calcu_a()
        sqrt_term = np.sqrt((j*x-f)**2-l*(m+n*x+o*x**2))
        result=np.sqrt(x**2+((f-j*x-sqrt_term )/p-a)**2)-self.R
        return result
        #return np.sqrt(x**2+((f-j*x-np.sqrt((j*x-f)**2-l*(m+n*x+o*x**2)))/p-a)**2)-self.R
    def Calcu_asphericity(self):  # 计算一定情况下的最大非球面度
        maximum_x=optimize.fminbound(lambda x:-self.find_asphericity(x),0,D/2)  # 使非球面度最大的x
        endpoint_left = self.find_asphericity(0)
        endpoint_right = self.find_asphericity(D/2)
        max_asphericity=self.find_asphericity(maximum_x)
        if max_asphericity < endpoint_left:
            max_asphericity = endpoint_left
        if max_asphericity < endpoint_right:
            max_asphericity = endpoint_right
        return max_asphericity

    def Draw_asphericity(self,R,a):    # 画出一定的R、a情况下的非球面度
        self.fig = plt.figure()
        self.ax  = self.fig.add_subplot(111)
        x=np.arange(0,D/2,0.1)
        sqrt_term = np.sqrt((j*x-f)**2-l*(m+n*x+o*x**2))
        y=np.sqrt(x**2+((f-j*x-sqrt_term)/p-a)**2)-R

        #y=np.sqrt(x**2+([f-j*x-np.sqrt[(j*x-f)**2-l*(m+n*x+o*x**2)]]/p-a)**2)-R
        self.ax.plot(x,y,'b')
        plt.show()

class Para_Calcu(object):

    def get_para(self):
        Interval = (advance_retreat_method(lambda R: One_Search(R).Calcu_asphericity()).run())   # 利用进退法搜索最优区间
        interval = np.arange(Interval[0], Interval[1], 0.01)
        result_stor = np.zeros(interval.shape)
        j = 0
        for i in interval:
            b = One_Search(i)
            result_stor[j] = b.Calcu_asphericity()
            j = j + 1
        min=np.min(result_stor)         # 检索最大非球面度的最小值
        index=np.argmin(result_stor)    # 检索min的索引值
        R=interval[index]               # 计算最佳拟合球面半径
        a=One_Search(R).Calcu_a()       # 计算球心坐标a的值

        return min,R,a

if __name__=='__main__':
    aspheric=Para_Calcu()
    Amax,R,a=aspheric.get_para()
    print(Amax,R,a)
    One_Search(R).Draw_asphericity(R,a)

    plt.show()